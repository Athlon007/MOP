=== Modern Optimization Plugin ===

Visit our GitHub repository! https://github.com/Athlon007/MOP
Download the newest update from RaceDepartment (https://www.racedepartment.com/downloads/mop-modern-optimization-plugin.30073/),
or from NexusMods (https://www.nexusmods.com/mysummercar/mods/146)

# INSTALLATION #
1.) Go to the folder where are your mods installed
2.) Paste the MOP.dll into it!


# CREDITS #
- Krutonium - original KruFPS creator, and the KruFPS contributors:
  - RedJohn260
  - EPS
- Est_Nbmstr - for clever name idea
- Icon made by Freepik from www.flaticon.com
- u/mrjackspede (from r/Unity3D) - free dynamic object occlusion script

# CONTACT #
Discord: Athlon#5974