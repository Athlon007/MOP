=== Modern Optimization Project ===

Visit our GitHub repository! https://github.com/Athlon007/MOP

# INSTALLATION #
1.) Go to the folder where are your mods installed
2.) Paste the MOP.dll into it!


# CREDITS #
- Krutonium - original KruFPS creator, and the KruFPS contributors:
  - RedJohn260
  - EPS
- Est_Nbmstr - for clever name idea
- Icon made by Freepik from www.flaticon.com


# CONTACT #
Discord: Athlon#5974